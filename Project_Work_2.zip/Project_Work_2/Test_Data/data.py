# This file consists of Test Information like username, password, XPATH etc

# Python Class for Username and Password
class Geetha_Data:
    username = "Admin"
    password = "admin123"
    search = "Admin"

# Python Class for Selenium Selectors
class Geetha_Selectors:
    input_box_username = "username"
    input_box_password = "password"
    login_xpath = '//*[@id="app"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button'

# Python Class for Search box
class Geetha_Admin:
    search_box_xpath = '//*[@id="app"]/div[1]/div[1]/aside/nav/div[2]/div/div/input'
    search_button = '//*[@id="app"]/div[1]/div[1]/aside/nav/div[2]/ul/li/a/span'
