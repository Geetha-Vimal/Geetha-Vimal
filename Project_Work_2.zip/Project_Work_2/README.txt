This is a Project Folder for "Project Guvi"

There are two Folder:-

1.) Test_Codes # It consists of Test Files

2.) Test_Data # it consists of Test Data's i.e. username, password, XPATH, ID, etc

NOTE # If you want to run a Test File Kindly go to the Test_Codes to run a specific Python Selenium Automation File.


COMMAND TO RUN A TEST FILE
--------------------------

pytest -v -s --capture=sys --html=D:\GUVI\Programs\Python\practical\reports\test_suman_UPDATED_1.html testGeetha.py

pytest -v -s --capture=sys --html=D:\GUVI\Programs\Python\APITesting\reports\test_suman_UPDATED_1.html geetha_api.py
