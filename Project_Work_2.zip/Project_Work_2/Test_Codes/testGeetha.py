from selenium import webdriver
from selenium.webdriver.common.by import By
from Test_Data import data
import pytest
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import unittest

class Test_Geetha:
    url = "https://opensource-demo.orangehrmlive.com"
    
    # Booting Method for running the Python Tests
    @pytest.fixture
    def booting_function(self):
        self.driver = webdriver.Chrome()
        yield
        self.driver.close()

    def test_get_title(self, booting_function):
        self.driver.get(self.url)
        assert self.driver.title == 'Geetha'
        assert self.driver.__class__ == 'oxd-text oxd-text--span oxd-main-menu-item--name'
        print("SUCCESS # Web Title Captured Successfully")

    def test_login(self, booting_function):
        self.driver.get(self.url)
        self.driver.maximize_window
        time.sleep(5)
        self.driver.find_element(by=By.NAME, value=data.Geetha_Selectors.input_box_username).send_keys(data.Geetha_Data.username)
        self.driver.find_element(by=By.NAME, value=data.Geetha_Selectors.input_box_password).send_keys(data.Geetha_Data.password)
        self.driver.find_element(by=By.XPATH, value=data.Geetha_Selectors.login_xpath).click()
        assert self.driver.title == 'OrangeHRM'
        print("SUCCESS # LOGGED IN WITH USERNAME {username} and PASSWORD {password}".format(username=data.Geetha_Data.username, password=data.Geetha_Data.password))

#    def test_admin(self, booting_function):
#        self.driver.get(self.url)
#        time.sleep(2)
#        self.driver.find_element(by=By.NAME, value=data.Geetha_Selectors.input_box_username).send_keys(data.Geetha_Data.username)
#        self.driver.find_element(by=By.NAME, value=data.Geetha_Selectors.input_box_password).send_keys(data.Geetha_Data.password)
#        self.driver.find_element(by=By.XPATH, value=data.Geetha_Selectors.login_xpath).click()
#        assert self.driver.title == 'OrangeHRM'
#        print("SUCCESS # LOGGED IN WITH USERNAME {username} and PASSWORD {password}".format(username=data.Geetha_Data.username, password=data.Geetha_Data.password))
#        time.sleep(2)
#        self.driver.find_element(by=By.XPATH, value=data.Geetha_Admin.search_box_xpath).send_keys(data.Geetha_Data.search)
#        self.driver.find_element(by=By.XPATH, value=data.Geetha_Admin.search_button).click()
#        time.sleep(2)
#        assert self.driver.__class__ == 'Admin'
#        print("SUCCESS # Searched IN WITH Admin tab")

