import pytest
from selenium import webdriver
from HACK_File import hotelbooking

@pytest.fixture()
class Geetha:
    web_driver = webdriver.chrome()
 
    # fetch the register of the page using Selenium
    def test_register_page(self, url):
        self.web_driver.get(url)
        return self.web_driver.register_page
        print("Register Successfully")
       
    # fetch the URL of the page
    def test_login_page(self, url):
        self.web_driver.get(url)
        return self.web_driver.current_url
        print("Login Successfully")
   
url = "https://adactinhotelapp.com/index.php"
 
s = Geetha()
 
print(s.test_register_pages(url))
 
print(s.test_login_page(url))
